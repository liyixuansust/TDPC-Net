
## Requirements
* python 3.6
* pytorch 0.4 or 1.0
* nibabel
* pickle 
* imageio
* pyyaml

## Implementation

Download the BraTS2018 dataset and change the path:

```
experiments/PATH.yaml
```

### Data preprocess
Convert the .nii files as .pkl files. Normalization with zero-mean and unit variance . 

```
python preprocess.py
```
### Training

The total training time is about 13 hours  when using randomly cropped volumes of size 128×128×128 and batch size 10 on Nvidia A40 GPU for 900 epochs.

```
python train_all.py --gpu=0 --cfg=TDPC_Net --batch_size=10
```
### Test

You could obtain the resutls as paper reported by running the following code:

```
python test.py --mode=1 --is_out=True --verbose=True --use_TTA=True --postprocess=True --snapshot=True --restore=model_last.pth --cfg=TDPC_Net --gpu=0
```
Then make a submission to the online evaluation server.



